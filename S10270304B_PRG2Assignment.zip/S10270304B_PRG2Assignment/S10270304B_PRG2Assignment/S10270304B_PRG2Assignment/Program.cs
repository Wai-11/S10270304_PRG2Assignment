﻿using System;
using System.Collections.Generic;
using System.IO;

//==========================================================
// Student Number   : S10270304
// Student Name     : Wai Zheng Quan
// Partner Name     : Koh Ming Feng
//==========================================================

class Program
{
    static Dictionary<string, string> airlines = new Dictionary<string, string>();
    static Dictionary<string, Flight> flights = new Dictionary<string, Flight>();
    static Dictionary<string, BoardingGate> boardingGates = new Dictionary<string, BoardingGate>();

    static void Main(string[] args)
    {
        

        LoadData();

        while (true)
        {
            Console.WriteLine("==============================");
            Console.WriteLine("Changi Airport Terminal 5");
            Console.WriteLine("==============================");
            Console.WriteLine("1. List All Flights");
            Console.WriteLine("2. List Boarding Gates");
            Console.WriteLine("3. Assign a Boarding Gate to a Flight");
            Console.WriteLine("4. Create a New Flight");
            Console.WriteLine("5. Display Airline Flights");
            Console.WriteLine("6. Modify Flight Details");
            Console.WriteLine("7. Display Flight Schedule");
            Console.WriteLine("8. Process all unassigned flights");
            Console.WriteLine("0. Exit");

            Console.Write("Please select your option: ");
            string choice = Console.ReadLine();

            try
            {
                switch (choice)
                {
                    case "1":
                        ListFlights();
                        break;
                    case "2":
                        ListBoardingGates();
                        break;
                    case "3":
                        AssignGate();
                        break;
                    case "4":
                        CreateFlight();
                        break;
                    case "5":
                        DisplayAirlineFlights();
                        break;
                    case "6":
                        ModifyFlight();
                        break;
                    case "7":
                        DisplayFlightSchedule();
                        break;
                    case "8":
                        ProcessUnassignedFlights();
                        break;
                    case "0":
                        Console.WriteLine("Goodbye!");
                        return;
                    default:
                        Console.WriteLine("Invalid option! Please try again.");
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
        }
    }

    static void LoadData()
    {
        try
        {
            Console.WriteLine("Loading airlines...");
            int airlineCount = -1;
            foreach (var line in File.ReadAllLines("airlines.csv"))
            {
                var parts = line.Split(',');
                airlines[parts[1].Trim()] = parts[0].Trim();
                airlineCount++;
            }

            Console.WriteLine($"{airlineCount} airlines loaded !.");

            Console.WriteLine("Loading Boarding Gates...");
            int gateCount = -1;
            foreach (var line in File.ReadAllLines("boardinggates.csv"))
            {
                var parts = line.Split(',');
                boardingGates[parts[0].Trim()] = new BoardingGate
                {
                    GateName = parts[0].Trim(),
                    SupportsDDJB = parts[1].Trim().Equals("TRUE", StringComparison.OrdinalIgnoreCase),
                    SupportsCFFT = parts[2].Trim().Equals("TRUE", StringComparison.OrdinalIgnoreCase),
                    SupportsLWTT = parts[3].Trim().Equals("TRUE", StringComparison.OrdinalIgnoreCase),
                    Assigned = false
                };
                gateCount++;
            }

            Console.WriteLine($"{gateCount} boarding gates loaded.");

            Console.WriteLine("Loading flights...");
            int flightCount = -1;
            foreach (var line in File.ReadAllLines("flights.csv"))
            {
                var parts = line.Split(',');
                string flightNumber = parts[0].Trim();
                string airline = flightNumber.Split(' ')[0];
                string origin = parts[1].Trim();
                string destination = parts[2].Trim();
                string time = parts[3].Trim();
                string? specialRequest = parts.Length > 4 ? parts[4].Trim() : null;

                if (specialRequest == "CFFT")
                {
                    flights[flightNumber] = new CFFTFlight(flightNumber, airline, origin, destination, time, 50.0);
                }
                else if (specialRequest == "LWTT")
                {
                    flights[flightNumber] = new LWTTFlight(flightNumber, airline, origin, destination, time, 75.0);
                }
                else if (specialRequest == "DDJB")
                {
                    flights[flightNumber] = new DDJBFlight(flightNumber, airline, origin, destination, time, 100.0);
                }
                else
                {
                    flights[flightNumber] = new NORMFlight(flightNumber, airline, origin, destination, time);
                }
                flightCount++;
            }

            Console.WriteLine($"{flightCount} flights loaded.");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error loading data: {ex.Message}");
        }
    }

    static void ListFlights()
    {
        Console.WriteLine("\n======================================================");
        Console.WriteLine("List of Flights for Changi Airport Terminal 5");
        Console.WriteLine("======================================================");
        Console.WriteLine($"{"Flight Number",-15}{"Airline Name",-20}{"Origin",-25}{"Destination",-25}{"Expected",-15}");
        Console.WriteLine(new string('-', 100));

        foreach (var flight in flights.Values)
        {
            string airlineName = airlines.ContainsKey(flight.Airline) ? airlines[flight.Airline] : "Unknown Airline";
            Console.WriteLine($"{flight.FlightNumber,-15}{airlineName,-20}{flight.Origin,-25}{flight.Destination,-25}{flight.Time,-15}");
        }
    }

    static void ListBoardingGates()
    {
        Console.WriteLine("==============================================================");
        Console.WriteLine("List of Boarding Gates for Changi Airport Terminal 5");
        Console.WriteLine("==============================================================");
        Console.WriteLine($"{"Gate Name",-15}{"DDJB",-20}{"CFFT",-20}{"LWTT",-20}");
        Console.WriteLine(new string('-', 62));

        foreach (var gate in boardingGates.Values)
        {
            Console.WriteLine($"{gate.GateName,-15}{gate.SupportsDDJB,-20}{gate.SupportsCFFT,-20}{gate.SupportsLWTT,-20}");
        }
    }

    static void AssignGate()
    {
        Console.WriteLine("\n======================================================");
        Console.WriteLine("Assign a Boarding Gate to a Flight");
        Console.WriteLine("======================================================");

        Console.Write("Enter Flight Number: ");
        string flightNum = Console.ReadLine();

        if (!flights.ContainsKey(flightNum))
        {
            Console.WriteLine("Invalid flight number!");
            return;
        }

        var flight = flights[flightNum];

        Console.WriteLine($"\nFlight Number: {flight.FlightNumber}");
        Console.WriteLine($"Origin: {flight.Origin}");
        Console.WriteLine($"Destination: {flight.Destination}");
        Console.WriteLine($"Expected Time: {flight.Time}");
        Console.WriteLine($"Special Request Code: {flight.SpecialRequest ?? "None"}");


        Console.Write("\nEnter Boarding Gate Name: ");
        string gateName = Console.ReadLine();

        if (!boardingGates.ContainsKey(gateName))
        {
            Console.WriteLine("Invalid gate name!");
            return;
        }

        var selectedGate = boardingGates[gateName];

        if (selectedGate.Assigned)
        {
            Console.WriteLine("Gate is already assigned!");
            AssignGate(); // Re-prompt for gate if already assigned.
            return;
        }

        flight.Gate = gateName;
        selectedGate.Assigned = true;


        Console.WriteLine($"\nBoarding Gate Name: {selectedGate.GateName}");
        Console.WriteLine($"Supports DDJB: {selectedGate.SupportsDDJB}");
        Console.WriteLine($"Supports CFFT: {selectedGate.SupportsCFFT}");
        Console.WriteLine($"Supports LWTT: {selectedGate.SupportsLWTT}");

        Console.Write("\nWould you like to update the status of the flight? (Y/N): ");
        string updateStatus = Console.ReadLine()?.Trim().ToUpper();

        if (updateStatus == "Y")
        {
            Console.WriteLine("\n1. Delayed");
            Console.WriteLine("2. Boarding");
            Console.WriteLine("3. On Time");
            Console.Write("Please select the new status of the flight: ");
            string statusChoice = Console.ReadLine();

            switch (statusChoice)
            {
                case "1":
                    flight.Status = "Delayed";
                    Console.WriteLine("Flight status updated to 'Delayed'.");
                    break;
                case "2":
                    flight.Status = "Boarding";
                    Console.WriteLine("Flight status updated to 'Boarding'.");
                    break;
                case "3":
                    flight.Status = "On Time";
                    Console.WriteLine("Flight status updated to 'On Time'.");
                    break;
                default:
                    Console.WriteLine("Invalid option! Keeping the current status.");
                    break;
            }
        }
        else
        {
            flight.Status = "On Time"; // Default status if user enters 'N'
        }

        Console.WriteLine($"\nFlight {flight.FlightNumber} has been assigned to Boarding Gate {gateName}!");
    }

    static void CreateFlight()
    {
        while (true)
        {
            try
            {
                Console.Write("\nEnter Flight Number: ");
                string flightNum = Console.ReadLine();

                Console.Write("Enter Origin: ");
                string origin = Console.ReadLine();

                Console.Write("Enter Destination: ");
                string destination = Console.ReadLine();

                Console.Write("Enter Expected Departure/Arrival Time (dd/mm/yyyy hh:mm): ");
                string time = Console.ReadLine();

                Console.Write("Enter Special Request Code (CFFT/DDJB/LWTT/None): ");
                string specialRequest = Console.ReadLine();

                flights[flightNum] = new Flight
                {
                    FlightNumber = flightNum,
                    Airline = flightNum.Split(' ')[0],
                    Origin = origin,
                    Destination = destination,
                    Time = time,
                    SpecialRequest = specialRequest == "None" ? null : specialRequest,
                    Status = "Scheduled"
                };

                Console.WriteLine($"\nFlight {flightNum} has been added!");

                // Prompt for adding another flight
                Console.Write("\nWould you like to add another flight? (Y/N): ");
                string addAnother = Console.ReadLine()?.Trim().ToUpper();

                if (addAnother != "Y")
                {
                    Console.WriteLine("Returning to the main menu...");
                    break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error creating flight: {ex.Message}");
            }
        }
    }

    static void DisplayAirlineFlights()
    {
        Console.WriteLine("\n======================================");
        Console.WriteLine("List of Airlines for Changi Airport Terminal 5");
        Console.WriteLine("======================================");
        Console.WriteLine($"{"Airline Code",-10}{"Airline Name",-30}");
        Console.WriteLine(new string('-', 40));

        foreach (var airline in airlines)
        {
            Console.WriteLine($"{airline.Key,-10}{airline.Value,-30}");
        }

        Console.Write("\nEnter Airline Code: ");
        string airlineCode = Console.ReadLine();

        if (!airlines.ContainsKey(airlineCode))
        {
            Console.WriteLine("Invalid Airline Code!");
            return;
        }

        Console.WriteLine($"\n======================================");
        Console.WriteLine($"List of Flights for {airlines[airlineCode]}");
        Console.WriteLine("======================================");
        Console.WriteLine($"{"Flight Number",-15}{"Airline Name",-20}{"Origin",-25}{"Destination",-25}{"Expected",-20}");
        Console.WriteLine(new string('-', 100));

        foreach (var flight in flights.Values)
        {
            if (flight.Airline == airlineCode)
            {
                string airlineName = airlines.ContainsKey(flight.Airline) ? airlines[flight.Airline] : "Unknown Airline";
                Console.WriteLine($"{flight.FlightNumber,-15}{airlineName,-20}{flight.Origin,-25}{flight.Destination,-25}{flight.Time,-20}");
            }
        }
    }

    static void DisplayFlightSchedule()
    {
        Console.WriteLine("\n=============================================================================================");
        Console.WriteLine("Flight Schedule for Changi Airport Terminal 5");
        Console.WriteLine("=============================================================================================");
        Console.WriteLine($"{"Flight Number",-12}{"Airline Name",-25}{"Status",-15}{"Origin",-15}{"Boarding Gate",-15}{"Destination",-15}{"Expected",-25}");
        Console.WriteLine(new string('-', 100));

        foreach (var flight in flights.Values)
        {
            string airlineName = airlines.ContainsKey(flight.Airline) ? airlines[flight.Airline] : "Unknown Airline";
            string boardingGate = flight.Gate ?? "Unassigned";
            Console.WriteLine($"{flight.FlightNumber,-12}{airlineName,-25}{flight.Status,-15}{flight.Origin,-15}{boardingGate,-15}{flight.Destination,-15}{flight.Time,-25}");
        }
        Console.WriteLine(new string('-', 100));
    }

    static void ModifyFlight()
    {
        Console.WriteLine("\n======================================================");
        Console.WriteLine("Modify Flight Details");
        Console.WriteLine("======================================================");
        Console.WriteLine($"{"Flight Number",-15}{"Airline Name",-25}{"Origin",-25}{"Destination",-25}{"Expected",-25}{"Status",-15}");
        Console.WriteLine(new string('-', 140));

        // Display all flights
        foreach (var flight in flights.Values)
        {
            string flightAirlineName = airlines.ContainsKey(flight.Airline) ? airlines[flight.Airline] : "Unknown Airline";
            Console.WriteLine($"{flight.FlightNumber,-15}{flightAirlineName,-25}{flight.Origin,-25}{flight.Destination,-25}{flight.Time,-25}{flight.Status,-15}");
        }

        // Prompt for flight selection
        Console.Write("\nEnter Flight Number to modify: ");
        string flightNum = Console.ReadLine();

        if (!flights.ContainsKey(flightNum))
        {
            Console.WriteLine("Invalid flight number! Returning to the main menu.");
            return;
        }

        var selectedFlight = flights[flightNum];

        Console.WriteLine("\nChoose an option to modify:");
        Console.WriteLine("1. Modify Basic Information");
        Console.WriteLine("2. Modify Status");
        Console.WriteLine("3. Modify Special Request Code");
        Console.WriteLine("4. Modify Boarding Gate");
        Console.WriteLine("5. Delete Flight");
        Console.Write("Enter your choice: ");
        string option = Console.ReadLine();

        switch (option)
        {
            case "1":
                // Modify basic information
                Console.Write("Enter new Origin: ");
                selectedFlight.Origin = Console.ReadLine();
                Console.Write("Enter new Destination: ");
                selectedFlight.Destination = Console.ReadLine();
                Console.Write("Enter new Expected Departure/Arrival Time (dd/mm/yyyy hh:mm): ");
                selectedFlight.Time = Console.ReadLine();
                Console.WriteLine("\nFlight updated!");
                break;

            case "2":
                // Modify status
                Console.WriteLine("\nChoose new status:");
                Console.WriteLine("1. Delayed");
                Console.WriteLine("2. Boarding");
                Console.WriteLine("3. On Time");
                Console.Write("Enter your choice: ");
                string statusChoice = Console.ReadLine();

                switch (statusChoice)
                {
                    case "1":
                        selectedFlight.Status = "Delayed";
                        break;
                    case "2":
                        selectedFlight.Status = "Boarding";
                        break;
                    case "3":
                        selectedFlight.Status = "On Time";
                        break;
                    default:
                        Console.WriteLine("Invalid status! Keeping the current status.");
                        break;
                }
                Console.WriteLine("\nFlight status updated!");
                break;

            case "3":
                // Modify special request code
                Console.Write("Enter new Special Request Code (DDJB/CFFT/LWTT/None): ");
                string specialRequest = Console.ReadLine();
                selectedFlight.SpecialRequest = specialRequest.Equals("None", StringComparison.OrdinalIgnoreCase) ? null : specialRequest;
                Console.WriteLine("\nSpecial request updated!");
                break;

            case "4":
                // Modify boarding gate
                Console.WriteLine("\nRedirecting to Assign Gate...");
                AssignGate();
                break;

            case "5":
                // Delete flight
                flights.Remove(flightNum);
                Console.WriteLine($"Flight {flightNum} deleted successfully!");
                break;

            default:
                Console.WriteLine("Invalid option! Returning to the main menu.");
                break;
        }

        // Display updated flight details
        Console.WriteLine("\n======================================================");
        Console.WriteLine("Updated Flight Details");
        Console.WriteLine("======================================================");
        Console.WriteLine($"Flight Number: {selectedFlight.FlightNumber}");
        Console.WriteLine($"Airline Name: {(airlines.ContainsKey(selectedFlight.Airline) ? airlines[selectedFlight.Airline] : "Unknown Airline")}");
        Console.WriteLine($"Origin: {selectedFlight.Origin}");
        Console.WriteLine($"Destination: {selectedFlight.Destination}");
        Console.WriteLine($"Expected Departure/Arrival Time: {selectedFlight.Time}");
        Console.WriteLine($"Status: {selectedFlight.Status}");
        Console.WriteLine($"Special Request Code: {selectedFlight.SpecialRequest ?? "None"}");
        Console.WriteLine($"Boarding Gate: {selectedFlight.Gate ?? "Unassigned"}");
        Console.WriteLine(new string('-', 140));
    }


    static void ProcessUnassignedFlights()
    {
        Queue<Flight> unassignedFlights = new Queue<Flight>();
        int totalAssigned = 0;
        int totalGatesAssigned = 0;

        // Step 1: Add all unassigned flights to a queue 
        foreach (var flight in flights.Values)
        {
            if (string.IsNullOrEmpty(flight.Gate))
            {
                unassignedFlights.Enqueue(flight);
            }
        }

        Console.WriteLine($"Total unassigned flights: {unassignedFlights.Count}");

        // Step 2: Assign flights to available gates 
        while (unassignedFlights.Count > 0)
        {
            var flight = unassignedFlights.Dequeue();
            BoardingGate assignedGate = null;

            // Check for a matching gate based on special request 
            if (!string.IsNullOrEmpty(flight.SpecialRequest))
            {
                foreach (var gate in boardingGates.Values)
                {
                    if (!gate.Assigned &&
                        ((flight.SpecialRequest == "DDJB" && gate.SupportsDDJB) ||
                         (flight.SpecialRequest == "CFFT" && gate.SupportsCFFT) ||
                         (flight.SpecialRequest == "LWTT" && gate.SupportsLWTT)))
                    {
                        assignedGate = gate;
                        break;
                    }
                }
            }

            // If no special gate found, assign any available gate 
            if (assignedGate == null)
            {
                foreach (var gate in boardingGates.Values)
                {
                    if (!gate.Assigned)
                    {
                        assignedGate = gate;
                        break;
                    }
                }
            }

            if (assignedGate != null)
            {
                flight.Gate = assignedGate.GateName;
                assignedGate.Assigned = true;
                totalAssigned++;
                totalGatesAssigned++;

                Console.WriteLine($"Assigned Gate {assignedGate.GateName} to Flight {flight.FlightNumber}");
            }
        }

        Console.WriteLine($"Total flights processed and assigned: {totalAssigned}");
        Console.WriteLine($"Total gates assigned: {totalGatesAssigned}");
    }

    // Other existing methods (LoadData, ListFlights, etc.) go here 
}


class Flight
    {
        public string FlightNumber { get; set; } = "";
        public string Airline { get; set; } = "";
        public string Origin { get; set; } = "";
        public string Destination { get; set; } = "";
        public string Time { get; set; } = "";
        public string? SpecialRequest { get; set; }
        public string? Gate { get; set; }
        public string Status { get; set; } = "Scheduled";
    }

    class BoardingGate
    {
        public string GateName { get; set; } = "";
        public bool SupportsDDJB { get; set; }
        public bool SupportsCFFT { get; set; }
        public bool SupportsLWTT { get; set; }
        public bool Assigned { get; set; }
    }

    class Airline
    {
        public string Code { get; set; } = "";
        public string Name { get; set; } = "";
        public Dictionary<string, Flight> Flights { get; set; } = new Dictionary<string, Flight>();
        public bool RemoveFlight(Flight flight)
        {
            return Flights.Remove(flight.FlightNumber);
        }
    }

    class Terminal
    {
        public string TerminalName { get; set; } = "";
        public Dictionary<string, Airline> Airlines { get; set; } = new Dictionary<string, Airline>();
        public Dictionary<string, Flight> Flights { get; set; } = new Dictionary<string, Flight>();
        public Dictionary<string, BoardingGate> BoardingGates { get; set; } = new Dictionary<string, BoardingGate>();
    }

    class NORMFlight : Flight
    {
        public NORMFlight(string flightNumber, string airline, string origin, string destination, string time)
        {
            FlightNumber = flightNumber;
            Airline = airline;
            Origin = origin;
            Destination = destination;
            Time = time;
        }
    }

    class CFFTFlight : Flight
    {
        public double RequestFee { get; set; }
        public CFFTFlight(string flightNumber, string airline, string origin, string destination, string time, double requestFee)
        {
            FlightNumber = flightNumber;
            Airline = airline;
            Origin = origin;
            Destination = destination;
            Time = time;
            RequestFee = requestFee;
        }
    }

    class LWTTFlight : Flight
    {
        public double RequestFee { get; set; }
        public LWTTFlight(string flightNumber, string airline, string origin, string destination, string time, double requestFee)
        {
            FlightNumber = flightNumber;
            Airline = airline;
            Origin = origin;
            Destination = destination;
            Time = time;
            RequestFee = requestFee;
        }
    }

    class DDJBFlight : Flight
    {
        public double RequestFee { get; set; }
        public DDJBFlight(string flightNumber, string airline, string origin, string destination, string time, double requestFee)
        {
            FlightNumber = flightNumber;
            Airline = airline;
            Origin = origin;
            Destination = destination;
            Time = time;
            RequestFee = requestFee;
        }
    }
